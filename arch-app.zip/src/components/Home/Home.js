import React from 'react'

function Home() {
  return (
    <div>
        <div id="carouselExampleCaptions" className="carousel slide" data-bs-ride="carousel">
            <div className="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div className="carousel-inner total_slider">
                <div className={"carousel-item active data-bs-interval=1000"}>
                    <div className="image">
                        <img src="img/1.jpg" className="d-block w-100 h-800" alt="..."/>
                    </div>
                    <div className="caption caption_vanish">
                        <h1>Leading sustainable parking design on Calgary's 9th Avenue</h1>
                        <a className="btn bg-transparent view_button" type="button">
                            View Project
                            <i className="las la-long-arrow-alt-right"></i>
                        </a>
                    </div>
                </div>
                <div className="carousel-item">
                    <div className="image">
                        <img src="img/2.jpg" className="d-block w-100 h-800" alt="..."/>
                    </div>
                    <div className="caption caption_vanish">
                        <h1>Leading sustainable parking design on Calgary's 9th Avenue</h1>
                    </div>
                </div>
                <div className="carousel-item">
                    <div className="image">
                        <img src="img/3.jpg" className="d-block w-100 h-800" alt="..."/>
                    </div>
                    <div className="caption caption_vanish">
                        <h1>Leading sustainable parking design on Calgary's 9th Avenue</h1>
                    </div>
                </div>
                <div className="slide_controls">

                </div>
            </div>

        </div>
    </div>
  )
}

export default Home